<!DOCTYPE html>
<link rel="stylesheet" href="res/assets/css/main.css" />
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        p {
            text-align: center;
        }

        h4 {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container">

        <br>
        <p><strong>Impressum</strong></p>
        <p>Anbieter:<br />Max Mustermann<br />Musterstraße 1<br />1220 Wien</p>
        <p>Kontakt:<br />Telefon: 043/1234567-8<br />Telefax: 043/1234567-9<br />E-Mail: mail@mustermann.at<br />Website: www.mustermann.at</p>
        <p> </p>
        <p>Bei redaktionellen Inhalten:</p>
        <p>Verantwortlich nach § 55 Abs.2 RStV<br />Moritz Schreiberling<br />Musterstraße 2<br />1220 Wien</p>
        <br>
        <h4>Project Team:</h4><br>
        <p><img src="./res/images/Samuel.png"><br><label>Samuel Pernthaler</label></p>
        <p><img src="./res/images/Franz.png"><br><label>Franz Schillinger</label></p>

    </div>

</body>

</html>