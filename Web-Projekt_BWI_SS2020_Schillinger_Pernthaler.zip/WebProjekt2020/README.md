# WebProjekt2020
WebProjekt 2020

Template Link: https://html5up.net/

Exportierte SQL Datei von phpMyAdmin --> config/webprojekt.sql
Datenbank File mit SQL befehlen -> Angaben/autogenerate_DB

Zugangsdaten Datenbank
    Host: localhost
    User: webProjekt
    Password: cprn66ae
    DBName: webprojekt
    
Standard/Test User
    Username: admin
    Password: admin
    Username: Samuel
    Password: 123
    Username: Franz
    Password: 123

Seite Laden von index.php

Farb Schema: #56435B
https://color.adobe.com/de/create/color-wheel

